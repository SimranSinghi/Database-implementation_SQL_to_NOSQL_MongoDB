HOW TO RUN THE PROGRAM:

-> Download VSCODE and MongoDB
-> Create database named COMPANY in Mongo DB Compass
-> Create collections named EMPLOYEE, DEPARTMENT, PROJECT and WORKS_ON
-> Upload the csv files in EMPLOYEE, DEPARTMENT, PROJECT and WORKS_ON collection one by one the mongo db compass
-> Set up connection to the local host:27017 in Mongo DB Compass
-> please see the requirement.txt for any package installation
-> Run main.py using the command "python main.py" or else you can click the play button above to run the program
-> Go to Mongo DB compass to see the Result files by clicking refresh button
-> Also, A "querydocument" will be generated. it contains the result of queries fired in the queries() function.

NOTE: PLease delete the results generated in MongoDB for executing the program as it may cause errors

EXTRA CREDIT:
-> JSON FILES and XML FILES FOLDERS will be created. 

